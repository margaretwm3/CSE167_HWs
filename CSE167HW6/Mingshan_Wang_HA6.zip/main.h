//
//  bezcurve.h
//  CSE167 HW6
//
//  Created by Mingshan Wang on 11/30/14.
//  Copyright (c) 2014 Mingshan Wang. All rights reserved.
//

#ifndef __CSE167_HW6__bezcurve__
#define __CSE167_HW6__bezcurve__

#include <stdio.h>

#endif /* defined(__CSE167_HW6__bezcurve__) */
