//
//  main.cpp
//  CSE167HW3
//
//  Created by Mingshan Wang on 11/4/14.
//  Copyright (c) 2014 Mingshan Wang. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
